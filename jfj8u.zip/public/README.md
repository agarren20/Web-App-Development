#Website to generate random quotes from Kanye West
#Author: Anna Garren
#Technologies:

- HTML
- CSS
- JavaScript

#Using an API, the website fetches data in order to output a randomly generated Kanye quote when the button is clicked. Clicking the button also prompts a sound to be played. The image as well has a sound attached to it when clicked.
#This isn't necessarily the most useful website, but it was fun to make
